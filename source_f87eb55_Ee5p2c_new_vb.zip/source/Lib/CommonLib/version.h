#if ! defined( VTM_VERSION )
#define VTM_VERSION "10.0"
#define ECM_VERSION "9.1"
#endif
